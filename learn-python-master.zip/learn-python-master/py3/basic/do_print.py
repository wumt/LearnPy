#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print('The quick brown fox', 'jumps over', 'the lazy dog')
print(300)
print(100 + 200)
print('100 + 200 =', 100 + 200)
