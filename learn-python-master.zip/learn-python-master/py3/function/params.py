#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def power(x, n=2):
    return x ** n

print('power(5) =', power(5))
print('power(5, 2) =', power(5, 2))
print('power(5, 4) =', power(5, 4))
